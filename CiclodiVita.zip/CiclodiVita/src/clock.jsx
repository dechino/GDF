import React from 'react' 
import Logger from './logger'
import LoggerFunz from './loggerfunz'


export default class Orologio extends React.Component{
    constructor(props){
        super(props)
        this.state = {oraCorrente:(new Date()).toLocaleTimeString(),
                      contatore:0}
        this.lanciaOrologio()
    }



    lanciaOrologio(){
      
        setInterval(() => {
            this.setState({oraCorrente:(new Date()).toLocaleTimeString(),
                contatore:++this.state.contatore})
        }, 1000);

    }


    render(){
        if (this.state.contatore>5 )
        return <div>
            <div>Stop Orologio.....</div>
        </div>
        else
        return (
            
            <div>
            {/*<Logger contatore ={this.state.contatore} oraCorrente = {this.state.oraCorrente}></Logger>*/}
            <LoggerFunz contatore ={this.state.contatore} oraCorrente = {this.state.oraCorrente}></LoggerFunz>
            </div>
        )
    }


}