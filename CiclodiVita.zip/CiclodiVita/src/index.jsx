import React from 'react' 
import ReactDOM from 'react-dom'
import Orologio from './clock'


ReactDOM.render(<Orologio/>,document.getElementById("content"))


