import React from 'react' 



//Montaggio di un componente
//1 costruttore                 inizializzo le variabili o lo stato  *****
//2 getDerivedStateFromProps    opero eventuali aggiornamenti di stato o di props
//3 render                      torna la grafica per ogni aggiornamento ****
//4 componentDidMount           qui si fanno le chiamate ajax           ****

//Aggiornamento di un componente
//1 getDerivedStateFromProps      opero eventuali aggiornamenti di stato o di props
//2 shouldComponentUpdate         puoi bloccare l'aggiornamento = il metodo render ****
//3 render                        torna la grafica per ogni aggiornamento
//4 componentDidUpdate            viene richiamato quando si aggiorna la grafica


//smontaggio
// 1 componentWillUnmount           richiamato quando si distrugge il componente (salvataggio)***


export default class Logger extends React.Component{
   
   
    constructor(props){
        super(props)
        console.log("costruttore")
    }

    static getDerivedStateFromProps(props,state){
            console.log("getDerivedStateFromProps",props,state)
    }

    componentDidMount(){
            console.log("componentDidMount")
    }


    componentDidUpdate(){
        console.log("componentDidUpdate")
    }
    shouldComponentUpdate(){
        if (this.props.contatore>3){
            return false
        }
            return true
    }





    render(){
        console.log("render")
        return <div>
            <h1>Orologio</h1>
            <h2>Ora corrente {this.props.oraCorrente}</h2>
        </div>
    }

    componentWillUnmount(){
        console.log("componentWillUnmount")
    }



}