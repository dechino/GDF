import React from 'react' 

export default function LoggerFunz(props){

//simile componentDidMount e componentDidUpdate
 React.useEffect(()=>{
     console.log("Dentro use effect",props.contatore)
 })   

 
console.log("LoggerFunz render")
return <div> 
          <div>
                <h1>Orologio</h1>
                <h2>Ora corrente {props.oraCorrente}</h2>
            </div>
        </div>

}