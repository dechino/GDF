const path = require("path")  //libreria di nodejs per utility di path
const HtmlWebpackPlugin = require('html-webpack-plugin')  //supporto ai file html



module.exports = {
    entry:'./src/index.jsx',    //punto di ingresso dell'applicazione
    output:{
        filename:"main.js",    //unico file di generazione di uscita      
        //__dirname è una costante di nodejs che punta al folder correntes   
        path:path.resolve(__dirname,'distribuzione')  //cartella di uscita

    },
    plugins:[
        new HtmlWebpackPlugin({
            template:'./src/index.html',
            inject:true,
            minify:{
                removeComments:true,
                collapseWhitespace:false
            }
        })
    ],
    resolve:{extensions:['.js','.ts','.jsx']},
    module:{
        rules:[
            {
              test:/\.js$|.ts$|.jsx$/ ,
              exclude:/(node_modules)/,
              use:{
                    loader:'babel-loader',
                    options:{
                        presets:[
                            '@babel/preset-env',
                            '@babel/preset-react',
                            '@babel/typescript'
                        ]
                    }        
              }

            }
        ]
    }

}