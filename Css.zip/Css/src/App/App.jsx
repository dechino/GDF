import React from 'react'

export default class App extends React.Component{

    constructor(props){
        super(props)
        this.state = {parcheggi:[]}
    }

    componentDidMount(){
        const url = "http://localhost:8000/api/parcheggi"
        fetch(url).then((response)=>response.json())
                  .then((auto)=>{this.setState({parcheggi:auto})})
    }

    render(){
        return (

                <div>
                    <ul>
                        {this.state.parcheggi.map((auto)=><li>{auto.nome}*{auto.cognome}*{auto.targa}</li>)}
                    </ul>
                </div>

        )
    }

}