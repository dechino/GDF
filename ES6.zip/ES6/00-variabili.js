
var pizza = true
pizza = false
console.log(pizza)

//aggiunta di const
/*
const pizza2 = true
pizza2 = false
*/

//aggiunta di let
/*
var topic = "Javascript"

if(topic){
    var topic = "React"
}

console.log(topic)
*/

let topic = "Javascript"

if(topic){
    let topic = "React"
    console.log(topic)
}

console.log(topic)


