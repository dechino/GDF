// concatenazioni di stringhe

const nome= "Pino"
const cognome ="Pini"
console.log("Nome:"+nome+" "+" cognome:"+cognome)

//template string

console.log(`Nome: ${nome} cognome: ${cognome}`)

console.log(`Nome: ${nome} 
                    cognome: ${cognome}`)