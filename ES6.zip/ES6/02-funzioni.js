//parametri di default
/*
function logActivity(nome="Roberto", attivita="docente"){

    console.log(`${nome}, ${attivita}`)
}


logActivity(nome="Giulio");


function objActivity(p = persona){
        console.log(p)
}

let persona = {
        nome:"Pino",
        cognome:"Pini"
}
objActivity()
*/


//arrow function

var anagrafica = function(nome,cognome){
    return `${nome} , ${cognome}`
}

console.log(anagrafica("Ciccio","Cicci"))

var anagraficaArrow = (nome,cognome)=>`${nome} , ${cognome}`

console.log(anagraficaArrow("Ciccio","Cicci"))



var miaApp = {
        mioArray : [1,2,3,4,5,6],
        stampa: function(){
            /*setTimeout(function(){
                console.log(this.mioArray)
            },0)
            */
           //la funzione freccia eredita il contesto dal padre!!!!!
            setTimeout(()=>{
                console.log(this.mioArray)
            },0)

           
        }
}

miaApp.stampa()

