const add = (x=5,y=10)=> console.log(x+y)


let variabile = "ciao"
for(let i = 0;i<3;i++){
    let variabile = "dentrociclo"
    console.log(variabile)
}
console.log(variabile)

add()