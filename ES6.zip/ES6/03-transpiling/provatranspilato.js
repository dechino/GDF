"use strict";

var add = function add() {
  var x = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 5;
  var y = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 10;
  return console.log(x + y);
};

var variabile = "ciao";

for (var i = 0; i < 3; i++) {
  var _variabile = "dentrociclo";
  console.log(_variabile);
}

console.log(variabile);
add();
