
//destrutturazione oggetti
/*
var obj  = {
    nome:"Gianni",
    eta:20,
    filmPreferito:"Star Wars",
    cibiPreferiti:["pasta","riso","carne"]
}

var {nome,eta,filmPreferito,cibiPreferiti} = obj

console.log(nome,eta,cibiPreferiti)
*/
//destrutturazione array
/*
let mioArray=["primo","secondo","terzo"]

var [uno] = mioArray
console.log(uno)

var[,,terzo] = mioArray

console.log(terzo)
*/

//spread operator

/*
var array1 = ["primo","secondo","terzo"]

var array2 = ["cinque","sei","sette","otto"]

var insieme = [...array1,...array2]
console.log(insieme)

var [ultimo] = insieme.reverse()
console.log(ultimo)
*/
//*****altro modo */
var tutti = ["primo","secondo","terzo","cinque","sei","sette","otto"]
/*
var [primo,...resto] = tutti

console.log(primo)

console.log(resto)
*/
function direzione(...args){
    var  [primo,...resto] = args
    var [ultimo,...stop] = resto.reverse()
    console.log(primo)
    console.log(ultimo)
    console.log(stop)
}
direzione("primo","secondo","terzo","cinque","sei","sette","otto")