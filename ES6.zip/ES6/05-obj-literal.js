var obj = {
    nome:"Pino",
    cognome:"Pini"
}

console.log(obj)

var nome = "Ciro"
var cognome = "Ciri"
var print=function(){console.log(this.nome,this.cognome)}
var obj2  = {nome,cognome,print}
console.log(obj2)
//Literal

obj2.print()


var obj3 = {
    nome:nome,
    cognome:cognome
}
console.log(obj3)

const obj4={
    nome,
    cognome,
    print
}

console.log(obj4)

