class Veicolo{
    constructor(haRuote,haMotore){
        this.haMotore = haMotore
        this.haRuote = haRuote
    }
    print(){
        console.log(` ${this.haMotore} , ${this.haRuote}`)
    }
}

const veicolo = new Veicolo(true,false)

veicolo.print()

class Auto extends Veicolo{
    constructor(modello,marca,haRuote,haMotore){
        super(haMotore,haRuote)
        this.modello = modello
        this.marca = marca
    }
    print(){
        super.print()
        console.log(` ${this.modello} , ${this.marca}`)
    }

}
var aAuto = new Auto("VW","Golf",true,true)
aAuto.print()

console.log(aAuto instanceof Veicolo,aAuto instanceof Auto)