// GET e SET

class Persona{
    
    constructor(nome){
        this._nome = nome
    }

    get nome(){
        return "***" + this._nome
    }    

    set nome(valore){
        this._nome = "YYY"+valore
    }

}

var p1 = new Persona("Roberto")
console.log(p1.nome)
p1.nome = "Pippo"
console.log(p1.nome)