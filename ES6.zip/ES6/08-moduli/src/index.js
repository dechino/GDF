
import {print as p, log as l} from './text'

p("Questo è il messaggio")

l("log del messaggio",new Date())