export const log = (messaggio,timestamp)=>{console.log(`Messaggio '${messaggio}, del ${timestamp.toString()}`)}
export const print = (messaggio) => log(messaggio,new Date())