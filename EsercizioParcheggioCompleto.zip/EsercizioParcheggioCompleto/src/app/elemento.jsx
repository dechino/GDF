import React from 'react' 


export default class Elemento extends React.Component{

    constructor(props){
        super(props)
        console.log("auto:",this.props.autoParcheggiata)
    }

    render(){
        return (
                <div>
                        <div className = "giallo">nome:
                        {this.props.autoParcheggiata.nome}
                        </div>
                        <div style={{fontSize:"30px"}}>cognome:
                        {this.props.autoParcheggiata.cognome}
                        </div>
                        <div>email:
                        {this.props.autoParcheggiata.email}
                        </div>
                        <div>telefono:
                        {this.props.autoParcheggiata.telefono}
                        </div>
                        <div>targa:
                        {this.props.autoParcheggiata.targa}
                        </div>
                </div>
        )
    }

}