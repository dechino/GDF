import React from 'react' 
import Elemento from './elemento'

export default class Lista extends React.Component{

    constructor(props){
        super(props)
        console.log(this.props.miaListaAuto)
    }


    render(){
        return(
            <div id="ListaComponent">
             {this.props.miaListaAuto.map((elemento)=>{return <Elemento autoParcheggiata = {elemento}></Elemento>})}    
            </div>
        )
    }
}