import App from './app/script'
import React from 'react' 
import ReactDOM from 'react-dom'


ReactDOM.render(<App/>,document.getElementById("content"))
