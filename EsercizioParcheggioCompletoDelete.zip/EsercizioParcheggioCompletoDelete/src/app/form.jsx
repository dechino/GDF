import React from 'react' 


export default class Form extends React.Component{

constructor(props){
    super(props)
    this.onChangeNome = this.onChangeNome.bind(this)
    this.onChangeCognome = this.onChangeCognome.bind(this)
    this.onChangeTelefono = this.onChangeTelefono.bind(this)
    this.onChangeEmail = this.onChangeEmail.bind(this)
    this.onChangeTarga = this.onChangeTarga.bind(this)
    this.parcheggia = this.parcheggia.bind(this)
    this.state={auto:{}}


}

onChangeNome(event){
    var autoLocale = this.state.auto
    autoLocale.nome = event.target.value
    this.setState({auto:autoLocale})
  
}

onChangeCognome(event){
    var autoLocale = this.state.auto
    autoLocale.cognome = event.target.value
    this.setState({auto:autoLocale})
}

onChangeTelefono(event){
    var autoLocale = this.state.auto
    autoLocale.telefono = event.target.value
    this.setState({auto:autoLocale})
}

onChangeEmail(event){
    var autoLocale = this.state.auto
    autoLocale.email = event.target.value
    this.setState({auto:autoLocale})
}
onChangeTarga(event){
    var autoLocale = this.state.auto
    autoLocale.targa = event.target.value
    this.setState({auto:autoLocale})
}


parcheggia(event){
        console.log("AUTO",this.state.auto)
        this.props.callback(this.state.auto)
}

render(){
    return(
        <div>
                <input type="text" placeholder="Nome" onChange={this.onChangeNome}  value={this.state.auto.nome}/>
                <input type="text" placeholder="Cognome" onChange={this.onChangeCognome}  value={this.state.auto.cognome}/>
                <input type="text" placeholder="Telefono" onChange={this.onChangeTelefono}  value={this.state.auto.telefono}/>
                <input type="text" placeholder="Email" onChange={this.onChangeEmail}  value={this.state.auto.email}/>
                <input type="text" placeholder="Targa" onChange={this.onChangeTarga}  value={this.state.auto.targa}/>
                <button onClick={this.parcheggia}>Parcheggia</button>        
            </div>

    )
}


}