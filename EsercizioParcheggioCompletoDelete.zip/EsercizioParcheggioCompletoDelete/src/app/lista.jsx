import React from 'react' 
import Elemento from './elemento'

export default class Lista extends React.Component{

    constructor(props){
        super(props)
        console.log(this.props.miaListaAuto)
        this.cancellaELista = this.cancellaELista.bind(this)
    }


    cancellaELista(targa){
        console.log("cancellaELista")
        this.props.cancellaElementoApp(targa)
    }


    render(){
        return(
            <div id="ListaComponent">
             {this.props.miaListaAuto.map((elemento)=>{return <Elemento autoParcheggiata = {elemento} cancellaElementoLista={this.cancellaELista}></Elemento>})}    
            </div>
        )
    }
}