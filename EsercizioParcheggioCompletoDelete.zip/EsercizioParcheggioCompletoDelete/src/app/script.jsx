import React from 'react' 
import Lista from './lista'
import Form from './form'


export default class App extends React.Component{

    constructor(props){
        super(props)
      
        this.state = {
            lista:[{nome:"Pino",cognome:"Pini",telefono:"1234567",email:"ppp@ggg.it",targa:"AA123BB"}],
        }

        this.richiamataDaForm = this.richiamataDaForm.bind(this)
        this.cancellaElemento = this.cancellaElemento.bind(this)
    }




    richiamataDaForm(nuovaAuto){
      console.log("richiamataDaForm",nuovaAuto)   
        var listaLocale = this.state.lista          
        let autoPresente = listaLocale.filter((auto)=>{
                            if (nuovaAuto.targa==auto.targa){
                                return auto
                            }
                    })[0]

        if (autoPresente){
            alert("Auto già presente nel parcheggio")
        }
        else{
        const autoClone = {...nuovaAuto}   //clonare l'oggetto
        listaLocale.push(autoClone)
        this.setState({lista:listaLocale,
                      })
        }
    } 

   cancellaElemento(targa){
    console.log("cancellaElementoApp")
    var listaLocale = this.state.lista  
    var nuovaLista =   listaLocale.filter((auto)=>{
                                    if (auto.targa!= targa)
                                             return auto})      
  

     this.setState({lista:nuovaLista})
    }

    render(){
        if (this.state.lista.length>0){
            return <div>
                        <Form callback = {this.richiamataDaForm}></Form>
                        <Lista miaListaAuto = {this.state.lista} cancellaElementoApp={this.cancellaElemento}></Lista>
                 </div>
        }
        else{
            return <div>
                      <Form></Form>
                    <h1>Nessun elemento nella lista</h1>
             </div>
        }
    }
}