//Creiamo un elemento (nome,parametro,figlio)

let h1 = React.createElement('h1',null,"Hello World!")


//let test = React.createElement('pippo',null,"Hello World!")
//utlizziamo react dom

ReactDOM.render(h1,document.getElementById("content"))