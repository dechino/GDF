//creazione componente
class HelloWorld extends React.Component{
    //deve contenere
   render(){
        return React.createElement('h1',null,'Hello world!')
    }

}

ReactDOM.render(
    React.createElement(HelloWorld)
    ,document.getElementById("content"))


/*   equivalente

    let h1 = React.createElement('h1',null,"Hello World!")
    ReactDOM.render(h1,document.getElementById("content"))   
*/