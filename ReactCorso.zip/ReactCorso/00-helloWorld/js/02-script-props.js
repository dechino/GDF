
/*   equivalente */
/*
    let h1 = React.createElement('h1',{id:"mioH1",title:"titolo",altraproprieta:"bla bla"},"Hello World!")
    ReactDOM.render(h1,document.getElementById("content"))   

*/


//creazione componente
// this.props all'interno di Component
class HelloWorld extends React.Component{
    //deve contenere
   render(){
        return React.createElement('h1',{id:this.props.id,title:this.props.title,altraproprieta:this.props.altraproprieta},'Hello world!')
    }

}

ReactDOM.render(
    React.createElement(HelloWorld,{id:"mioH1",title:"titolo",altraproprieta:"bla bla"})
    ,document.getElementById("content"))




