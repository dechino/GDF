
let h1 = React.createElement('h1',null,"Hello World")

//creazione componente
// this.props all'interno di Component
class HelloWorldRipetuta extends React.Component{
    //deve contenere
   render(){
        return React.createElement('div',null,h1,h1,h1)
    }

}

ReactDOM.render(
    React.createElement(HelloWorldRipetuta)
    ,document.getElementById("content"))




