
class HelloWorld extends React.Component{
    //deve contenere
   render(){
        return React.createElement(
            'h1',
            this.props,
            "Ciao "+ this.props.nome)
    }

}

ReactDOM.render(
    React.createElement("div",
    null,
    React.createElement(HelloWorld,{
        id:"idMario",
        nome:"Mario",
        title:"Bella persona"
    }),
    React.createElement(HelloWorld,{
        id:"idLuigi",
        nome:"Luigi",
        title:"Bella persona"
    }),
    React.createElement(HelloWorld,{
        id:"idFrancesco",
        nome:"Francesco",
        title:"Bella persona"
    }),
    )
    ,document.getElementById("content"))




