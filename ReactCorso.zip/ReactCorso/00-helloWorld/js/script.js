class MiaEtichetta extends React.Component{
render(){
    return React.createElement(
        'label',
        this.props,
        'For ' + this.props.htmlFor +" ! "
    )
}
}

class MioSpan extends React.Component{
    render(){
        return React.createElement(
            'span',
            this.props,
            'Class ' + this.props.className +" ! "
        )
    }
}

ReactDOM.render(
    React.createElement(
        "div",
        null,
        React.createElement(MiaEtichetta,
            {id:"React",
            htmlFor:"react input",
            style:{fontSize:"30px",backgroundColor:"red"}
        }),
        React.createElement(MioSpan,
            {id:"ReactSpan",
            className:"giallo",
            style:{fontSize:"30px"}
        })
    ),document.getElementById("content")
)



//le proprieta css
// background-color -> backgroundColor
// font-size -> fontSize

//2 eccezioni
// class ->className
// for -> htmlFor




