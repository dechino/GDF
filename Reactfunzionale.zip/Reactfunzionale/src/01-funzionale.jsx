//import App from './app/script'
import React from 'react' 
import ReactDOM from 'react-dom'


function Pulsante(){
   const  gestisci= ()=>{
       console.log("pulsante premuto.....")
    }
    return <button onClick={gestisci}>Premi</button>
}


function SottoElemento(){

    return <div>questo è un sottoelemento</div>
}

function App(props){
    return <div>
            <h1>{props.proprieta}  **** <SottoElemento></SottoElemento></h1>
            <Pulsante></Pulsante>
        </div>
}





