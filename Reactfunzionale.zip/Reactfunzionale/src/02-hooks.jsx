//import App from './app/script'
import React from 'react' 
import ReactDOM from 'react-dom'


//HOOKS

export function TestUseState(){
        //state
        //count rappresenta la varabile che vuoi cambiare
        //setConteggio rappresenta la funzione da richiamare per cambiare la variabile
        //React.useState(0) imposta a 0 il valore della variabile iniziale

    const[count,setConteggio] = React.useState(0)
    const aumentaCount = ()=>{
            setConteggio(count + 1 )
    }

    return <div>
            <p>useState api</p>
            <p>Conteggio:{count} <button onClick={aumentaCount}>Aumenta</button></p>
            </div>
}



export function TestUseStateObject(){
    //state
    
const[state,setState] = React.useState({
    count:0,
    saluta:"Ciao Mondo"
})
const impostaState = ()=>{
    setState(
        {
           count:state.count + 1,
           saluta:"Ho gia salutato"

        }
    )

}


console.log("state",state)
return <div>
        <p>useStateObject api</p>
        <p>Conteggio:{state.count}</p>
        <p>Saluta:{state.saluta}</p>
        <button onClick={impostaState}>Cambia Stato</button>
        </div>
}





