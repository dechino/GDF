import React from 'react' 
import ReactDOM from 'react-dom'
import {TestUseState,TestUseStateObject} from './02-hooks'



function Totale(){
    return <div>
        <TestUseState></TestUseState>
        <TestUseStateObject></TestUseStateObject>
    </div>
}


ReactDOM.render(<Totale/>,document.getElementById("content"))


