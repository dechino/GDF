var a = {0:"10",1:"20",2:"30",2:"40"}

for (var appo in a){
    console.log(a[appo])
}

var b = new Array(10)
b[150]="prrrrrr"

for (var appo in b){
    console.log(b[appo])
}

console.log("Dimensione di a", a.length)
console.log("Dimensione di b", b.length)