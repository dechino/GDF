function moltiplica(a,b){
    return a*b 
}


console.log(moltiplica(3,4));


var moltiplica2 = function(a,b){
    return a*b
}

console.log(moltiplica2(3,4));



var moltiplica3 = new Function("a","b","return a*b")

console.log(moltiplica3(3,4));



function operazioneMatematica(func,a,b){
    return (func(a,b))
}



console.log(operazioneMatematica(moltiplica,3,4))


function somma(a,b){
    return a+b
}

console.log(operazioneMatematica(somma,3,4))




function sommaParametri(a,b,c){
    console.log("sommaParametri prima func",a,b,c)
}



var sommaParametri = function(a,b){
    console.log("sommaParametri prima func2222",a,b)
}


sommaParametri(3,4)




