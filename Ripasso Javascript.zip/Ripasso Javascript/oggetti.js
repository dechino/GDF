//oggetto anonimo
var persona1 = new Object()
persona1.nome="Ciro"
persona1.cognome="Ciri"
persona1.anno = 1980
persona1.parla = function(){console.log("sto parlando...")}

console.log(persona1.nome,persona1.cognome,persona1.anno)
persona1.parla()

console.log(persona1 instanceof Object)

//oggetto anonimo

var persona2 = Object.create(null)
persona2.nome="Ciro"
persona2.cognome="Ciri"
persona2.anno = 1980
persona2.parla = function(){console.log("sto parlando...")}

console.log(persona2.nome,persona2.cognome,persona2.anno)
persona2.parla()

console.log(persona2 instanceof Object)




//creazione di oggetto mediante prototipo

function Persona(nome,cognome,eta){
    this.nome = nome
    this.cognome = cognome
    this.eta = eta
    this.parla = function(){
        console.log("sto parlando...")
    }
}

var persona3 = new Persona("Mario","Mari",1970)
console.log(persona3.nome,persona3.cognome,persona3.eta)
persona3.parla()

console.log(persona3 instanceof Object)
console.log(persona3 instanceof Persona)



//creazione di oggetto mediante notazione JSON

var persona4 = {
    nome:"Pino",
    cognome:"Pini",
    eta:1960,
    parla:function(){
        console.log("sto parlando...")
    }
}

console.log(persona4 instanceof Object)
console.log(persona4.nome,persona4.cognome,persona4.eta)
persona4.parla()


console.log(persona1["nome"])
console.log(persona2["nome"])
console.log(persona3["nome"])
console.log(persona4["nome"])

console.log(String(persona4["parla"]))
