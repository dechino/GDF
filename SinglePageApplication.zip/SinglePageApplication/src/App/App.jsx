import React from 'react'
import Home from './Components/Home'
import About from './Components/About'
import Parametro from './Components/Parametro'
import Dinamica from './Components/Dinamica'

//librerie per il routing
import {BrowserRouter as Router,  //wrapper totale del routing
        Route,                    // è la singola rotta  
        Link,                     //è il collegamento alla rotta  
        Switch                    //è l'if della rotta (=switch case)  
        ,
    } from 'react-router-dom'



export default class App extends React.Component{
    constructor(props){
        super(props)
    }
    render(){
        const param="12345"
        const mioArrayId =[{id:1},{id:2},{id:3}]
        return (

                <Router>
                        <div className="App">

                            <div className="container">
                                <ul>
                                    <li><Link to="/home">Home</Link></li>
                                    <li><Link to="/about">About</Link></li>
                                    <li><Link to={"/parametro/"+param}>Parametro</Link></li>
                                    {mioArrayId.map((elem)=><li key={elem.id}><Link to={"/dinamica/"+elem.id}>Dinamica :{elem.id}</Link></li>)}
                                </ul>
                            <hr></hr>
                            <hr></hr>
                            <Switch>
                                <Route exact path="/" component= {Home} />
                                <Route path="/home" component= {Home} />
                                <Route path="/about" component= {About} />
                                <Route path="/parametro/:parampassato" component= {Parametro} />

                                {mioArrayId.map((elem)=><Route key={elem.id} path={"/dinamica/:numero"} component={props =><Dinamica {...props}/>}></Route>)}


                            </Switch>

                            </div>
                        </div>

                </Router>








        )
    }
}
