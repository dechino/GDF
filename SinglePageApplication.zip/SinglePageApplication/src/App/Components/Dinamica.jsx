import React from "react";


export default class Dinamica extends React.Component{
        constructor(props){
            super(props)
             this.numero = props.match.params.numero      
             this.state = {numerostate:props.match.params.numero}

        }

        static getDerivedStateFromProps(props,state){
            console.log("getDerivedStateFromProps",props.match.params.numero)
            return {numerostate:props.match.params.numero}
        }

        componentWillUnmount(){
            console.log("componentWillUnmount")
        }

        render(){
            console.log("render")
            return (
                <div>
                <h1> Dinamica  props!!! {this.numero} </h1>
                <h1> Dinamica  state!!! {this.state.numerostate} </h1>
            </div>
            )
        }

}