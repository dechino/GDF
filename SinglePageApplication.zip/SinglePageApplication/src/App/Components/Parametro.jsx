import React from 'react' 
 const Parametro = (props)=>{
     const param = props.match.params.parampassato
    return (
        <div>
            <h1> Parametro !!! </h1>
            <h3> Il parametro passato è : {param} </h3>
        </div>
    )
}
export default Parametro