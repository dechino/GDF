console.log("typescript")

//tipi primitivi

var nome:string = "Pippo"

var quantita:number = 10

var isVero:boolean = true


var qualunque:any = "uuuuu"

var qualunque2:any = 12

var qualunque3:any = true


//tipo complesso

var data:Date = new Date()

var gg:number = data.getDay()


//array

var valori:number[] = []


//array multidimensionali

var arrayMulti :number[][] = [[1,2,3],[4,5,6]]






