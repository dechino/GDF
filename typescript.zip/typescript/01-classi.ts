class EssereVivente{
    private _numorgani:number;

    constructor(numerogani:number) {
        this._numorgani = numerogani
    }

    public get numorgani():number{
        return this._numorgani

  }
    public set numorgani(valore:number){
        this._numorgani = valore
    }

}

class Persona extends EssereVivente{
    nome
    eta

    constructor(nome:string,eta:string,numerogani:number) {
        super(numerogani)
        this.nome = nome
        this.eta = eta
    }


   stampa(){
       console.log(this.nome + " " + this.eta+ " " + this.numorgani)
   }


}

let essere = new EssereVivente(10)
essere.numorgani = 20
console.log(essere.numorgani)


let p1 = new Persona("Gino","31",10)

p1.stampa()