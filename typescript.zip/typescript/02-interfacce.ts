interface IPersona{
    nome:string
    cognome:string
    saluta:()=>string
}

/*
function stampaPersona(p:IPersona){
  console.log(p.nome+ " " +p.cognome)
  var a:any = p
  console.log(a.eta)
}



var obj = {
     nome:"Pino",
     cognome:"Pini",
     saluta:()=>{return "Ciao"},
     eta:10
}

stampaPersona(obj);
*/


interface ILavoratore extends IPersona{
    stipendio:number
    segretaria?:string //? opzionale
}



class Falegname implements ILavoratore{
    stipendio: number = 0;
    segretaria?: string | undefined;
    nome: string;
    cognome: string;
    
    
    constructor(){
     //   this.stipendio = 0
        this.nome = ""
        this.cognome = ""

    }


    saluta(){ return "Ciao"}
}

var fal = new Falegname()

console.log(fal instanceof Falegname)





