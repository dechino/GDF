import { waitForDebugger } from "inspector"
/*
function identitaOld(arg:number):number{
    return arg
}

console.log(identitaOld(2))

function identita<T>(arg:T):T{
  return arg
} 

console.log(identita<number>(2))

console.log(identita<boolean>(true))

console.log(identita<string>("2"))

*/

/*

interface IIdentita<V,W>{
    id1:V,
    id2:W
}

function identitaInterface<T,U>(arg1:T,arg2:U):IIdentita<T,U>{
    console.log(arg1 + " :" + typeof(arg1))
    console.log(arg2 + " :" + typeof(arg2))

    let obj:IIdentita<T,U> = {
        id1:arg1,
        id2:arg2
    }
    return obj
}

console.log(JSON.stringify(identitaInterface<number,string>(10,"ciao")))

*/


enum difficolta{facile = "facile",medio="medio",difficile="difficile"}

let reac_info = {
    nome:"react",
    superset:"Javascript",
    difficolta:difficolta.medio
}


function dammiProprieta<T,K extends keyof T>(obj:T,key:K):T[K]{
    return obj[key]
}

let estraidifficolta:difficolta = dammiProprieta(reac_info,"difficolta")

console.log(estraidifficolta.valueOf())








