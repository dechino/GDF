import { Categoria } from "./enums";

export interface Libro{
    id:number
    titolo:string;
    categoria:Categoria
}