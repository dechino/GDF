import { Categoria } from "./enums";
import { Libro } from "./Libro";

function dammiLibri():Libro[]{
    let libri  = [
            {id:1,titolo:"Ulisse",categoria:Categoria.Storia},
            {id:2,titolo:"Mody Dick",categoria:Categoria.Fiction},
            {id:3,titolo:"La cavallina storna",categoria:Categoria.Storia}

    ]
    return libri;
}

console.log(dammiLibri())