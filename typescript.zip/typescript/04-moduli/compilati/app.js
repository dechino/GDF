"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var enums_1 = require("./enums");
function dammiLibri() {
    var libri = [
        { id: 1, titolo: "Ulisse", categoria: enums_1.Categoria.Storia },
        { id: 2, titolo: "Mody Dick", categoria: enums_1.Categoria.Fiction },
        { id: 3, titolo: "La cavallina storna", categoria: enums_1.Categoria.Storia }
    ];
    return libri;
}
console.log(dammiLibri());
