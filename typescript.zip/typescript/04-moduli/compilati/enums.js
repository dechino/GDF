"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Categoria = void 0;
var Categoria;
(function (Categoria) {
    Categoria[Categoria["Biografia"] = 0] = "Biografia";
    Categoria[Categoria["Poesia"] = 1] = "Poesia";
    Categoria[Categoria["Fiction"] = 2] = "Fiction";
    Categoria[Categoria["Storia"] = 3] = "Storia";
})(Categoria = exports.Categoria || (exports.Categoria = {}));
