"use strict";
/*function corso(target:any){

    Object.defineProperty(target.prototype,'getCorso',{value:(str:string)=>"Corso GDF " +str})
}


@corso
class Uomo{
    nome
    cognome

    constructor(nome:string,cognome:string){
        this.nome = nome;
        this.cognome = cognome
    }
}


let uomo:any = new Uomo("Roby","Desa")
console.log(uomo.getCorso("oggi"))


*/
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
function Primo() {
    console.log("Primo()");
    return function (target, propertyKey, descriptor) {
        console.log("Chiamato Primo()");
    };
}
function Secondo() {
    console.log("Secondo()");
    return function (target, propertyKey, descriptor) {
        console.log("Chiamato Secondo()");
    };
}
var ClasseEsempio = /** @class */ (function () {
    function ClasseEsempio() {
    }
    ClasseEsempio.prototype.mioMetodo = function () { };
    __decorate([
        Primo(),
        Secondo()
    ], ClasseEsempio.prototype, "mioMetodo", null);
    return ClasseEsempio;
}());
