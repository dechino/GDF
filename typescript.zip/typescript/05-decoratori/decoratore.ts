/*function corso(target:any){

    Object.defineProperty(target.prototype,'getCorso',{value:(str:string)=>"Corso GDF " +str})
}


@corso
class Uomo{
    nome
    cognome

    constructor(nome:string,cognome:string){
        this.nome = nome;
        this.cognome = cognome
    }
}


let uomo:any = new Uomo("Roby","Desa")
console.log(uomo.getCorso("oggi"))


*/

function Primo(){
    console.log("Primo()")
    return function(target:any,propertyKey:string,descriptor:PropertyDescriptor){
        console.log("Chiamato Primo()")
    }
}

function Secondo(valore:boolean){
    console.log("Secondo()") 
    return function(target:any,propertyKey:string,descriptor:PropertyDescriptor){
        descriptor.enumerable = valore
        console.log("Chiamato Secondo()")
    }
}



class ClasseEsempio{


    
        @Primo()
        @Secondo(false)
        mioMetodo(){}






    }
