import {Header} from './app/header'
console.log("WebPack tutorialffffff")


var intestazione = new Header()
console.log(intestazione.getHeader())