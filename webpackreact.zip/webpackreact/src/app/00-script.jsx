
import React from 'react' 

//let mioh1 = React.createElement("h1",null,"hello world")
let mioH1JSX = <h1 id="pippo">Hello world</h1>

export default class HelloWorld extends React.Component{
    render(){
        return (
                <div>
                    {mioH1JSX}
                    {mioH1JSX}
                    {mioH1JSX}
                    {mioH1JSX}
               </div>
              )
    }
}


