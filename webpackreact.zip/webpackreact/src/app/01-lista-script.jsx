import React from "react";


class App extends React.Component{ 
    render(){
        const lista = ["primo","secondo","terzo","quarto"];
        return <TodoList miaLista = {lista}/>
    }
}


class TodoList extends React.Component{
    render(){
        var lista = this.props.miaLista
        return <ul>
                {lista.map((elemento)=><Item messaggio ={elemento} key={elemento}/>)}
        </ul>
    }
}


class Item extends React.Component{
    render(){
              
        return(<li>{this.props.messaggio}</li>
        )

    }
}



export default App