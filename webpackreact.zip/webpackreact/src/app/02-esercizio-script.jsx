//esercizio
import React from "react";
var aeroporti = new Array(6);
				
aeroporti[0]={
	"partenza":"Roma",
	"destinazioni":["Berlino","Madrid","Parigi","Tallinn","San Pietroburgo","Londra","Edimburgo","Praga","Valencia","Stoccolma"]
};


aeroporti[1]={
	"partenza":"Londra",
	"destinazioni":[
	"Barcellona","Francoforte","Copenhagen","Stoccarda",
	"Roma","Pisa","Praga","Bruxelles","Marsiglia"]
};


aeroporti[2]={
	"partenza":"Francoforte",
	"destinazioni":[
	"Riga","Lisbona","Parigi","Roma","Venezia",
	"Londra","Helsinki","Sofia","Siviglia","Rennes"]
};

aeroporti[3]={
	"partenza":"Madrid",
	"destinazioni":[
	"Berlino","LOndra","Bordeaux","Tallinn","Oslo",
	"Firenze","Milano","Genova","Zurigo","Stoccolma"]
};

aeroporti[4]={
	"partenza":"Berlino",
	"destinazioni":[
	"Dresda","Svolvaer","Parigi","Mosca","Pisa",
	"Londra","Helsinki","Dublino","Stoccarda","Stoccolma"]
};

aeroporti[5]={
	"partenza":"Parigi",
	"destinazioni":[
	"Pisa","Madrid","Berlino","Zurigo","Tallinn",
	"Londra","Monaco","Atene","Berna","Basilea"]
};



class App extends React.Component{
    
    getPartenze(){
        return aeroporti.map((elem)=>{return elem.partenza})
    }
    
    render(){
      return  <MiaSelect lista = {this.getPartenze()}/>
    }
}


class MiaSelect extends  React.Component{

    creaOptions(){
        return  this.props.lista.map((elem)=><MiaOption valore={elem} key={elem}></MiaOption>)

    }

    render(){
      return   <select>
                    {this.creaOptions()}
               </select>
    }
}


class MiaOption extends React.Component{
    render(){
            return (
                <option {...this.props}>{this.props.valore}</option>
            )
    }
}

export default App