
import React from 'react' 


//componente stateless
class App extends React.Component{
    render(){
        console.log("render di App")
        return <Orologio/>
    }
}
export default App


//componenti stateful
class Orologio extends React.Component{
  
    constructor(props){
        super(props)
        //inizializzando lo stato con una proprieta che si chiama tempo
        this.state = {tempo:new Date().toLocaleTimeString()}  
        this.aggiornaTempo()
        console.log("costruttore")
    }

    aggiornaTempo(){
        setInterval(
            ()=>{
                //metodo obbligatorio per aggiornare lo stato
                console.log("dentro aggiornaTempo")
                this.setState({tempo:new Date().toLocaleTimeString()})
            }
            //o gestisco il bind
           /* function(){
                this.setState({tempo:new Date().toLocaleTimeString()})
            }.bind(this)
            ,1000
            */

              //o gestisco il self
           /*   
            var self = this
            function(){
                self.setState({tempo:new Date().toLocaleTimeString()})
            }
            ,1000
            */
        )
    }


    render(){
        console.log("render di orologio")
        return(
        <div>
            <h1>Orologio</h1>
            <h2>{this.state.tempo}</h2>
        </div>
)
    }
}