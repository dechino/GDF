export class Header{
    constructor(){
        console.log('Costruttore di Header')
    }
    getHeader():string{
        return "Prova TypeScriptHeader"
    }
}



export const miaVariabile = "valore";