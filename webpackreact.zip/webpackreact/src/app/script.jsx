
import React from 'react' 

//== Reeact.createElement()
const  HelloWorldElement = <h1> Hello World</h1>

class HelloWorld extends React.Component{
    render(){
        return <div>{HelloWorldElement}</div>
    }
}

export default HelloWorld
