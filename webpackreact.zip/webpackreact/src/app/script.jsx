
import React from 'react' 


//componente stateless
class App extends React.Component{
    render(){
        console.log("render di App")
        return <Bottoni/>
        
    }
}
export default App


class Bottoni  extends React.Component{

    constructor(props){
        super(props)
        this.miaFunzione = this.miaFunzione.bind(this)  //sto riscrivendo la funzione bindandola al this
        this.gestisciMioTesto = this.gestisciMioTesto.bind(this)
        this.manipolaSave = this.manipolaSave.bind(this)
      
        var miaLista = ["uno","due","tre"]
        this.state = {mioTesto:"",lista:miaLista}
    }

    miaFunzione(e){
        console.log("mia funzione")
        console.log(this,e)
        //gestisco mioTesto  1 modo
        var testo = document.getElementById("mioTesto").value
        console.log(testo)
    }

    //***** */ gestisco mioTesto  2 modo
    gestisciMioTesto(event){
        this.setState({mioTesto:event.target.value})
    }

    manipolaSave(){
        //chiamata al server.......
        console.log("Invio.....",this.state.mioTesto)
    }
    //************

    render(){
        console.log("dentro render",this)
        return (<div>
                        <input id="mioTesto" type="text" placeholder ="scrivi qualcosa....." onChange={this.gestisciMioTesto}/>
                        <button onClick={(e)=>{console.log(this,e)}}>Evento embedded</button>
                        <button onClick={(e)=>{this.miaFunzione(e)}}>Evento funzione lambda esterna</button>
                    { /*   <button onClick={this.miaFunzione.bind(this)}>Evento funzione senza lambda esterna</button> */}
                         <button onClick={this.miaFunzione}>Evento funzione senza lambda esterna</button> 
                         <button onClick={this.manipolaSave}>Salva</button> 

                        <ul>
                        {this.state.lista.map((elemento)=><li key={elemento}>{elemento}</li>)}
                        </ul>
               </div>


        )
    }


}