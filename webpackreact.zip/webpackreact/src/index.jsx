
import {Header} from './app/header'
import HelloWorld from './app/script'
import React from 'react' 
import ReactDOM from 'react-dom'

console.log("WebPack tutorialffffff")

var intestazione = new Header()
console.log(intestazione.getHeader())

ReactDOM.render(<HelloWorld/>,document.getElementById("content"))
